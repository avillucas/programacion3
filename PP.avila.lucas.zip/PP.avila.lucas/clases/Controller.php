<?php 
class Controller
{

	/**
	 * caso: crearUsuario (post): Se deben guardar los siguientes datos: nombre, apellido, email y foto. Los
	 * datos se guardan en el archivo de texto usuarios.txt, tomando el email como identificador.	 *
	 * @return void
	 */
	public static function crearUsuario()
	{	
		$email = Router::getPostParam('email');		
		$collection = new usuarioCollection();
		if($collection->find($email))
		{
			throw new Exception('El usuario con email '.$email.' ya existe');
		}
		//
		$nombre = Router::getPostParam('nombre');
		$imagePath = self::cargarImagen($nombre);
		
		$apellido = Router::getPostParam('apellido');
		$usuario = new Usuario( $nombre, $apellido,$email,$imagePath);
		//		
		$collection->save($usuario);
		Router::sendJsonRespons('Creado correctamente',200);
	}

	/**
	 * caso: buscarUsuario (get): Se ingresa apellido, si coincide con algún registro del archivo usuarios.txt se
	 * retorna todos los alumnos con dicho apellido, si no coincide se debe retornar “No existe usuario con apellido
	 * xxx” (xxx es el apellido que se buscó) La búsqueda tiene que ser case insensitive.
	 */
	public static function buscarUsuario()
	{
		$apellido = Router::getGuetParam('apellido');
		$collection = new usuarioCollection();
		$usuarios = $collection->findApellido($apellido);
		if(!count($usuarios)){
			Router::sendResponse('No existe usuario con apellido '.$apellido,404);
		}			
		Router::sendJsonRespons($usuarios,200);
	}

	 /**
	  * caso: listarUsuarios (get): Muestra un listado con todos los datos de los usuarios.
	  */
	public static function listarUsuarios()
	{
		$collection = new usuarioCollection();
		Router::sendJsonRespons($collection->__toArray());
	}

	private static function cargarImagen($path)
	{
			//ADD FOTO
			$fileData = Router::getFile('foto');
			// NOMBRE DEL ARCHIVO 
			$fileName = Router::slug($path);
			//crear la carpeta
			IO::createIfNotExists(FOTOS_DIR);    
			//ARMAR EL NOMBRE DEL ARCHIVO CON LA EXTENSION  DEStino 
			$filePath = $fileName.'.'. Router::getExtension($fileData['name']);
		
			//
			$newpath =FOTOS_DIR.$filePath;        
			
			if(file_exists($newpath))
			{
				//crear la carpeta
				IO::createIfNotExists(BACKUP_DIR);    
				//backupear el archivo
				$backupPath = IO::backupFile($filePath,FOTOS_DIR,BACKUP_DIR);
			}

			//subir el archivo 
			$filePath = IO::uploadFile($fileData,$newpath);
			
			if($filePath === false )
			{
				throw new \ErrorException('NO se pudo guardar la imagen');
			}
			return $filePath;
	}


	private static function cargarImagenMensaje($path)
	{
			//ADD FOTO
			$fileData = Router::getFile('foto');
			// NOMBRE DEL ARCHIVO 
			$fileName = Router::slug($path);
			//crear la carpeta
			IO::createIfNotExists(MSG_FOTOS_DIR);    
			//ARMAR EL NOMBRE DEL ARCHIVO CON LA EXTENSION  DEStino 
			$filePath = $fileName.'.'. Router::getExtension($fileData['name']);
		
			//
			$newpath =MSG_FOTOS_DIR.$filePath;        
			
			
			//subir el archivo 
			$filePath = IO::uploadFile($fileData,$newpath);
			
			if($filePath === false )
			{
				throw new \ErrorException('NO se pudo guardar la imagen');
			}
			return $filePath;
	}


	/**
	 *  Se recibe el email del remitente, email del destinatario y mensaje y se
	 * guardan los datos en el archivo mensajes.txt.
	 */
	public static function cargarMensaje()
	{
		$remitenteEmail = Router::getPostParam('emailr');
		$destinatarioEmail = Router::getPostParam('emaild');
		$mensaje = Router::getPostParam('mensaje');
		$msj = new Mensaje($remitenteEmail,$destinatarioEmail,$mensaje);
		$mensajeCollection = new MensajeCollection();
		$mensajeCollection->save($msj);						
        Router::sendJsonRespons('El mensaje se creo correctamente',201);
	}

	/**
	 * caso: mensajesRecibidos (get): Se recibe email del usuario y se muestran todos los mensajes que
	 * recibió.
	 */
	public static function mensajesRecibidos()
	{
		$emailDestinatario = Router::getGuetParam('emaild');
		$mensajeCollection = new MensajeCollection();
		$mensajes = $mensajeCollection->byDestinatario($emailDestinatario);
		if(!count($mensajes)){
			Router::sendResponse('No existen mensajes para '.$emailDestinatario,404);
		}			
		Router::sendJsonRespons($mensajes,200);
	}

	/**
	 *  caso: mensajesEnviados(get): Se recibe email del usuario y se muestran todos los mensajes que mando.
	 */
     public static function mensajesEnviados()
    {
		$emailRemitente = Router::getGuetParam('emailr');
		$mensajeCollection = new MensajeCollection();
		$mensajes = $mensajeCollection->byRemitente($emailRemitente);
		if(!count($mensajes)){
			Router::sendResponse('No existen mensajes de '.$emailRemitente,404);
		}			
		Router::sendJsonRespons($mensajes,200);	
	}

		/**
	 *  caso: modificarUsuario(post): Debe poder modificar todos los datos del usuario menos el email y
	 * guardar la foto antigua en la carpeta /backUpFotos , el nombre será el apellido y la fecha.

	 *
	 */

	public static function modificarUsuario()
	{
		$email = Router::getPostParam('email');		
		$collection = new usuarioCollection();
		$usuario = $collection->find($email);
		if(!$usuario)
		{
			throw new Exception('El usuario con email '.$email.' no existe');
		}
		//
		$nombre = Router::getPostParam('nombre');		
		$apellido = Router::getPostParam('apellido');
		$usuario->setNombre($nombre);
		$usuario->setApellido($apellido);			
		$imagePath = self::cargarImagen($nombre);		
		$collection->save($usuario);
		Router::sendJsonRespons('Modificado correctamente',200);
	}


	/**
	 *  caso: mensajes: Se mostraran todos los mensajes de todos los usuarios con foto incluida. 
	 */
	public static function mensajes()
	{
	 	throw new Exception('no implementado');	
	}

}

