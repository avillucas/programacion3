<?php 
class Mensaje
{	
	private $emailRemite;
    private $emailDestinatario;
	private $mensaje;

	public function __construct($emailRemite, $emailDestinatario,$mensaje )
	{		
		$this->emailRemite  = $emailRemite;
		$this->emailDestinatario  = $emailDestinatario;
		$this->mensaje  = $mensaje;	
	}	

	public function __toArray()
	{
		return ['emailRemite' => $this->emailRemite,'emailDestinatario'=>$this->emailDestinatario, 'mensaje' => $this->mensaje];
	}

	public function __toJson()
	{
		return json_encode($this->__toArray());
	}

	public static function populate($item)
	{
		return  new Mensaje($item['emailRemite'],$item['emailDestinatario'],$item['mensaje']);
	}

}