<?php 
class MensajeCollection
{
    private $items ;
	private $puntero = 0;
	const FILE_DIR = 'datos';
	const FILE_NAME = 'mensajes.txt';

	public function __construct()
	{
		$this->items = [];
		$this->load();		
	}

	public function save(Mensaje &$mensaje)
	{	
							
		$this->items[] = $mensaje->__toArray();
		$this->saveData();
	}

	private function saveData()
	{
		$content = json_encode($this->items, true);		
		IO::writeJson($content,self::FILE_DIR,self::FILE_NAME);
	}

	private  function load()
	{
		$items = IO::readJson(self::FILE_DIR,self::FILE_NAME);
		if($items !== false)
		{
			$this->items = (empty($items)) ? []:$items;
		}
	}

	public  function __toJson()
	{
		return json_encode($this->items, true);		
	}

	public  function __toArray()
	{		
		return $this->items;
	}

	public function count()
	{
		return count($this->items);
	}	

	public function byDestinatario($emailDestinatario)
	{
		$out = []; 
		foreach($this->items as $k => $item)
		{
			if(strtolower($item['emailDestinatario']) == strtolower($emailDestinatario))
			{
				$out[] = $item;
			}	
		}
		return $out;
    }
    
    public function byRemitente($emailRemitente)
	{
		$out = []; 
		foreach($this->items as $k => $item)
		{
			if(strtolower($item['emailRemite']) == strtolower($emailRemitente))
			{
				$out[] = $item;
			}	
		}
		return $out;
    }
}