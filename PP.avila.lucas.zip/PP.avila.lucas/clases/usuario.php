<?php 
class Usuario 
{	
	private $nombre;
    private $apellido;
	private $email;
	private $image;

	public function __construct($nombre, $apellido,$email,$image )
	{		
		$this->email  = $email;
		$this->nombre  = $nombre;
		$this->apellido  = $apellido;		
		$this->image= $image;      
	}	

	public function __toString()
	{
		return  'nombre:'.$this->nombre.'apellido:'.$this->apellido.' <br/>email:'.$this->email.' <br/>image:'.$this->image ;
	}

	public function __toArray()
	{
		return ['nombre' => $this->nombre,'apellido'=>$this->apellido, 'email' => $this->email,'image'=>$this->image];
	}

	public function __toJson()
	{
		return json_encode($this->__toArray());
	}

	public static function populate($item)
	{
		return  new Usuario($item['nombre'],$item['apellido'],$item['email'],$item['image']);
	}
	
	public function getNombre()
	{
		return $this->nombre;
	}

	public function getApellido()
	{
		return $this->apellido;
	}

	public function getEmail()
	{
		return $this->email;
	}
	
	public function setNombre($nombre)
	{
		$this->nombre = $nombre;
	}

	public function setApellido($apellido)
	{
		$this->apellido = $apellido;
	}

	public function setEmail($email)
	{
		$this->email = $email;
	}

}