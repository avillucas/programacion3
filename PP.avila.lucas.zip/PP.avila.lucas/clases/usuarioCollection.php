<?php 
class usuarioCollection
{
    private $items ;
	private $puntero = 0;
	const FILE_DIR = 'datos';
	const FILE_NAME = 'usuarios.txt';

	public function __construct()
	{
		$this->items = [];
		$this->load();		
	}

	

	public function save(Usuario &$usuario)
	{	
							
		$this->items[$usuario->getEmail()] = $usuario->__toArray();
		$this->saveData();
	}

	private function saveData()
	{
		$content = json_encode($this->items, true);		
		IO::writeJson($content,self::FILE_DIR,self::FILE_NAME);
	}

	private  function load()
	{
		$items = IO::readJson(self::FILE_DIR,self::FILE_NAME);
		if($items !== false)
		{
			$this->items = (empty($items)) ? []:$items;
		}
	}

	public  function __toJson()
	{
		return json_encode($this->items, true);		
	}

	public  function __toArray()
	{		
		return $this->items;
	}

	public function count()
	{
		return count($this->items);
	}	

	public function find($email)
	{
		foreach($this->items as $emailK => $item)
		{
			if($emailK == $email)
			{
				return Usuario::populate($item);
			}	
		}
		return false;
	}

	public function findApellido($apellido)
	{
		$out = []; 
		foreach($this->items as $emailK => $item)
		{
			if(strtolower($item['apellido']) == strtolower($apellido))
			{
				$out[] = $item;
			}	
		}
		return $out;
	}	

}