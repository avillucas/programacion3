<?php 
include_once('config.php');
include_once(CLASES_DIR.'router.php');
include_once(CLASES_DIR.'Controller.php');
include_once(CLASES_DIR.'IO.php');
include_once(CLASES_DIR.'usuario.php');
include_once(CLASES_DIR.'usuarioCollection.php');
include_once(CLASES_DIR.'mensaje.php');
include_once(CLASES_DIR.'mensajeCollection.php');
//
try{
    switch(Router::getCaso())
    {
        case 'crearUsuario': Controller::crearUsuario();break;
        case 'buscarUsuario': Controller::buscarUsuario();break;
        case 'listarUsuarios': Controller::listarUsuarios();break;
        case 'cargarMensaje': Controller::cargarMensaje();break;
        case 'mensajesRecibidos': Controller::mensajesRecibidos();break;
        case 'mensajesEnviados': Controller::mensajesEnviados();break;
        case 'mensajesEnviados': Controller::mensajesEnviados();break;
        case 'modificarUsuario': Controller::modificarUsuario();break;
        case 'mensajes': Controller::mensajes();break;
        default:
            throw new Exception('El caso $caso no existe ');
        break;
        
    }
}
catch(Exception $e)
{
    Router::sendJsonRespons($e->getMessage(),402);
}

