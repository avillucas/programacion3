-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: mysql.div-it.com.ar
-- Tiempo de generación: 12-11-2018 a las 16:20:38
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sacipeventos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividades`
--

CREATE TABLE `actividades` (
  `id` int(10) UNSIGNED NOT NULL,
  `evento_id` int(10) UNSIGNED NOT NULL,
  `inicio` datetime NOT NULL,
  `fin` datetime NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `descripcion_html` text COLLATE utf8mb4_unicode_ci,
  `lugar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `activity_log`
--

INSERT INTO `activity_log` (`id`, `user_id`, `text`, `ip_address`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Evento 1 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(2, NULL, 'Evento 2 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(3, NULL, 'Evento 3 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(4, NULL, 'Evento 4 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(5, NULL, 'Evento 5 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(6, NULL, 'Evento 6 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(7, NULL, 'Evento 7 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(8, NULL, 'Evento 8 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(9, NULL, 'Evento 9 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(10, NULL, 'Evento 10 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(11, NULL, 'Usuario 1 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(12, NULL, 'Usuario 2 creado', '127.0.0.1', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(13, NULL, 'Usuario 3 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(14, NULL, 'Usuario 4 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(15, NULL, 'Usuario 5 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(16, NULL, 'Usuario 6 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(17, NULL, 'Usuario 7 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(18, NULL, 'Usuario 8 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(19, NULL, 'Usuario 9 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(20, NULL, 'Usuario 10 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(21, NULL, 'Usuario 11 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(22, NULL, 'Usuario 12 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(23, NULL, 'Usuario 13 creado', '127.0.0.1', '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(24, NULL, 'Usuario 14 creado', '127.0.0.1', '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(25, NULL, 'Usuario 15 creado', '127.0.0.1', '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(26, NULL, 'Usuario 16 creado', '127.0.0.1', '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(27, NULL, 'Usuario 17 creado', '127.0.0.1', '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(28, NULL, 'Usuario 18 creado', '127.0.0.1', '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(29, NULL, 'Usuario 19 creado', '127.0.0.1', '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(30, NULL, 'Usuario 20 creado', '127.0.0.1', '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(31, NULL, 'Participante 1 creado', '190.104.233.251', '2018-10-26 21:55:08', '2018-10-26 21:55:08'),
(32, NULL, 'Participante 1 actualizado', '190.104.233.251', '2018-10-26 21:56:03', '2018-10-26 21:56:03'),
(33, 2, 'Ingreso al sistema', '190.104.233.251', '2018-10-26 21:56:09', '2018-10-26 21:56:09'),
(34, NULL, 'Participante 1 actualizado', '190.104.233.251', '2018-10-26 21:56:11', '2018-10-26 21:56:11'),
(35, NULL, 'Cerro sesion', '190.104.233.251', '2018-10-26 21:56:13', '2018-10-26 21:56:13'),
(36, NULL, 'Participante 2 creado', '190.104.233.251', '2018-10-26 21:57:05', '2018-10-26 21:57:05'),
(37, NULL, 'Participante 1 actualizado', '190.104.233.251', '2018-10-26 22:00:19', '2018-10-26 22:00:19'),
(38, NULL, 'Participante 1 actualizado', '190.104.233.251', '2018-10-26 22:01:07', '2018-10-26 22:01:07'),
(39, NULL, 'Participante 1 actualizado', '190.104.233.251', '2018-10-26 22:01:23', '2018-10-26 22:01:23'),
(40, NULL, 'Participante 3 creado', '190.104.233.251', '2018-10-26 22:03:20', '2018-10-26 22:03:20'),
(41, NULL, 'Participante 4 creado', '190.104.233.251', '2018-10-26 22:09:35', '2018-10-26 22:09:35'),
(42, NULL, 'Participante 2 actualizado', '190.104.233.251', '2018-10-26 22:10:07', '2018-10-26 22:10:07'),
(43, NULL, 'Participante 5 creado', '190.104.233.251', '2018-10-26 22:11:28', '2018-10-26 22:11:28'),
(44, NULL, 'Participante 2 actualizado', '190.104.233.251', '2018-10-26 22:12:36', '2018-10-26 22:12:36'),
(45, NULL, 'Participante 6 creado', '190.104.233.251', '2018-10-26 22:53:57', '2018-10-26 22:53:57'),
(46, NULL, 'Participante 2 actualizado', '190.104.233.251', '2018-10-26 22:54:41', '2018-10-26 22:54:41'),
(47, NULL, 'Participante 7 creado', '190.104.233.251', '2018-10-26 22:55:11', '2018-10-26 22:55:11'),
(48, NULL, 'Participante 2 actualizado', '190.104.233.251', '2018-10-26 22:59:27', '2018-10-26 22:59:27'),
(49, NULL, 'Participante 6 actualizado', '190.104.233.251', '2018-10-26 23:00:41', '2018-10-26 23:00:41'),
(50, NULL, 'Participante 6 actualizado', '190.104.233.251', '2018-10-26 23:01:13', '2018-10-26 23:01:13'),
(51, NULL, 'Participante 6 actualizado', '190.104.233.251', '2018-10-26 23:01:31', '2018-10-26 23:01:31'),
(52, NULL, 'Cerro sesion', '190.104.233.251', '2018-10-26 23:01:53', '2018-10-26 23:01:53'),
(53, 2, 'Ingreso al sistema', '190.104.233.251', '2018-10-26 23:01:57', '2018-10-26 23:01:57'),
(54, NULL, 'Cerro sesion', '190.104.233.251', '2018-10-26 23:02:23', '2018-10-26 23:02:23'),
(55, NULL, 'No pudo ingresar', '190.104.233.251', '2018-10-26 23:03:24', '2018-10-26 23:03:24'),
(56, 1, 'Ingreso al sistema', '190.104.233.251', '2018-10-26 23:03:28', '2018-10-26 23:03:28'),
(57, 1, 'Participante 1, NICO@NICO.COM, ASDAS borrado', '190.104.233.251', '2018-10-26 23:03:39', '2018-10-26 23:03:39'),
(58, 1, 'Participante 2, avillucas@gmail.com, asdasdasdasd borrado', '190.104.233.251', '2018-10-26 23:03:57', '2018-10-26 23:03:57'),
(59, 1, 'Participante 4, nico@divit.com.ar, Nico borrado', '190.104.233.251', '2018-10-26 23:04:02', '2018-10-26 23:04:02'),
(60, 1, 'Participante 3, NBOC@ASD.COM, nICO borrado', '190.104.233.251', '2018-10-26 23:04:08', '2018-10-26 23:04:08'),
(61, 1, 'Participante 5, nico@go.com, Nico borrado', '190.104.233.251', '2018-10-26 23:04:15', '2018-10-26 23:04:15'),
(62, 1, 'Participante 6, nico@sad.com, asdsa borrado', '190.104.233.251', '2018-10-26 23:04:19', '2018-10-26 23:04:19'),
(63, 1, 'Participante 7, acas@as.comas, adasd borrado', '190.104.233.251', '2018-10-26 23:04:24', '2018-10-26 23:04:24'),
(64, 1, 'Ingreso al sistema', '190.104.233.251', '2018-10-29 17:00:06', '2018-10-29 17:00:06'),
(65, NULL, 'Participante 8 creado', '80.134.234.63', '2018-10-31 23:30:04', '2018-10-31 23:30:04'),
(66, NULL, 'Participante 9 creado', '190.104.233.251', '2018-11-01 23:09:59', '2018-11-01 23:09:59'),
(67, NULL, 'Participante 10 creado', '181.230.156.157', '2018-11-02 21:30:39', '2018-11-02 21:30:39'),
(68, NULL, 'Participante 11 creado', '179.7.192.37', '2018-11-04 18:38:05', '2018-11-04 18:38:05'),
(69, NULL, 'Participante 12 creado', '5.102.238.248', '2018-11-05 12:17:00', '2018-11-05 12:17:00'),
(70, NULL, 'Participante 13 creado', '190.129.0.130', '2018-11-05 21:09:42', '2018-11-05 21:09:42'),
(71, NULL, 'Participante 14 creado', '181.211.243.29', '2018-11-07 20:23:46', '2018-11-07 20:23:46'),
(72, NULL, 'Participante 15 creado', '181.114.126.167', '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(73, NULL, 'Participante 16 creado', '190.93.208.171', '2018-11-08 17:22:58', '2018-11-08 17:22:58'),
(74, NULL, 'Participante 17 creado', '190.31.42.101', '2018-11-09 07:26:15', '2018-11-09 07:26:15'),
(75, 2, 'Ingreso al sistema', '181.167.4.164', '2018-11-13 01:36:46', '2018-11-13 01:36:46'),
(76, NULL, 'Cerro sesion', '181.167.4.164', '2018-11-13 01:46:00', '2018-11-13 01:46:00'),
(77, 4, 'Ingreso al sistema', '181.167.4.164', '2018-11-13 01:46:27', '2018-11-13 01:46:27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuestas`
--

CREATE TABLE `encuestas` (
  `id` int(10) UNSIGNED NOT NULL,
  `participante_id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `razon_social` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comentario` text COLLATE utf8mb4_unicode_ci,
  `newsletter_cloud` tinyint(1) NOT NULL DEFAULT '0',
  `newsletter_seguridad` tinyint(1) NOT NULL DEFAULT '0',
  `newsletter_smart_steps` tinyint(1) NOT NULL DEFAULT '0',
  `newsletter_wirless_vpn` tinyint(1) NOT NULL DEFAULT '0',
  `newsletter_markeing_dinamico` tinyint(1) NOT NULL DEFAULT '0',
  `newsletter_uccas` tinyint(1) NOT NULL DEFAULT '0',
  `opinion_evento` enum('V','B','R','M') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `id` int(10) UNSIGNED NOT NULL,
  `path` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `edificio` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lugar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitud` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitud` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inicio` date NOT NULL,
  `hora` time NOT NULL,
  `tipo` enum('C','P','I') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `cupo` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`id`, `path`, `nombre`, `edificio`, `direccion`, `lugar`, `latitud`, `longitud`, `inicio`, `hora`, `tipo`, `cupo`, `created_at`, `updated_at`) VALUES
(1, 'sacil-2019', 'Sacil 2019', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'C', NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(2, 'laparoscopia-en-oncologia-ginecologica', 'Laparoscopía en Oncología Ginecológica', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'P', NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(3, 'laparoscopia-en-patologia-benigna', 'Laparoscopía en Patología Benigna', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Bahía Blanca,            Buenos Aires', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'P', NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(4, 'histeroscopia', 'Histeroscopía', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'P', NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(5, 'uroginecologia', 'Uroginecología', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'P', NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(6, 'laparoscpopia-hands-on-en-animales', 'Laparoscpopía Hands On en Animales', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'P', 15, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(7, 'laparoscpopia-en-pelvic-trainers', 'Laparoscpopía en Pelvic Trainers', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'P', 20, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(8, 'leep-en-ginecologia', 'LEEP en Ginecología', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'P', 5, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(9, 'imagenes-en-ginecologia', 'Imágenes en Ginecología', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'I', NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(10, 'nudos-y-suturas', 'Nudos y Suturas', 'Hotel Panamericano', 'Carlos Pellegrini 551', 'Ciudad Autónoma de Buenos Aires, Argentina', '-34.601904', '-58.380946', '2018-04-03', '09:00:00', 'I', NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2018_08_19_060905_create_eventos_table', 1),
(9, '2018_08_19_062109_create_usuarios_eventos_table', 1),
(10, '2018_08_19_062400_create_participantes_table', 1),
(11, '2018_08_19_063232_create_encuestas_table', 1),
(12, '2018_08_19_065124_create_sorteos_table', 1),
(13, '2018_08_21_022452_create_permission_tables', 1),
(14, '2018_09_05_151851_create_activity_log_table', 1),
(15, '2018_09_09_220550_create_actividades', 1),
(16, '2018_10_05_210328_create_notificaciones', 1),
(17, '2018_10_07_232830_create_tarifas_table', 1),
(18, '2018_10_08_013042_create_transacciones_table', 1),
(19, '2018_10_08_015238_create_transacciones_tarifas', 1),
(20, '2018_10_08_025405_create_participante_eventos', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(1, 'App\\User', 2),
(1, 'App\\User', 3),
(1, 'App\\User', 4),
(1, 'App\\User', 5),
(1, 'App\\User', 6),
(1, 'App\\User', 7),
(1, 'App\\User', 8),
(1, 'App\\User', 9),
(1, 'App\\User', 10),
(1, 'App\\User', 11),
(1, 'App\\User', 12),
(1, 'App\\User', 13),
(1, 'App\\User', 14),
(1, 'App\\User', 15),
(1, 'App\\User', 16),
(1, 'App\\User', 17),
(1, 'App\\User', 18),
(1, 'App\\User', 19),
(1, 'App\\User', 20);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(10) UNSIGNED NOT NULL,
  `transaccion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `valido` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `transaccion`, `data`, `valido`, `created_at`, `updated_at`) VALUES
(1, '80', '{\"date\":\"2018.10.31 02:32:06\",\"pse_reference3\":null,\"payment_method_type\":\"2\",\"pse_reference2\":null,\"franchise\":\"VISA\",\"commision_pol\":\"0.00\",\"pse_reference1\":null,\"shipping_city\":null,\"bank_referenced_name\":null,\"sign\":\"837391c352450a2296d2ea1cd72a358d\",\"extra2\":null,\"extra3\":null,\"payment_request_state\":\"A\",\"billing_address\":null,\"extra1\":null,\"administrative_fee\":\"0.00\",\"administrative_fee_tax\":\"0.00\",\"bank_id\":\"257\",\"nickname_buyer\":null,\"payment_method\":\"257\",\"attempts\":\"1\",\"transaction_id\":\"2b806803-0a11-4dcc-897e-6127efa3e46d\",\"transaction_date\":\"2018-10-31 14:32:06\",\"test\":\"0\",\"exchange_rate\":\"1.00\",\"ip\":\"80.134.234.63\",\"reference_pol\":\"1078047178\",\"cc_holder\":\"Erica Weber\",\"tax\":\"0.00\",\"antifraudMerchantId\":null,\"pse_bank\":null,\"state_pol\":\"4\",\"billing_city\":null,\"phone\":null,\"error_message_bank\":null,\"shipping_country\":\"AR\",\"error_code_bank\":\"0\",\"cus\":\"150372979\",\"commision_pol_currency\":null,\"customer_number\":null,\"description\":\"Compra para la transaccion :80\",\"merchant_id\":\"638749\",\"administrative_fee_base\":\"0.00\",\"authorization_code\":\"013974\",\"currency\":\"ARS\",\"shipping_address\":null,\"nickname_seller\":null,\"cc_number\":\"************3878\",\"installments_number\":\"1\",\"value\":\"9000.00\",\"transaction_bank_id\":\"013974\",\"billing_country\":\"AR\",\"response_code_pol\":\"1\",\"payment_method_name\":\"VISA\",\"office_phone\":null,\"email_buyer\":\"ericacweber@yahoo.com.ar\",\"payment_method_id\":\"2\",\"response_message_pol\":\"APPROVED\",\"airline_code\":null,\"risk\":\"0.0\",\"reference_sale\":\"80\",\"additional_value\":\"0.00\"}', 1, '2018-10-31 23:32:08', '2018-10-31 23:32:08'),
(2, '82', '{\"date\":\"2018.11.02 12:35:19\",\"pse_reference3\":null,\"payment_method_type\":\"2\",\"pse_reference2\":null,\"franchise\":\"MASTERCARD\",\"commision_pol\":\"0.00\",\"pse_reference1\":null,\"shipping_city\":null,\"bank_referenced_name\":null,\"sign\":\"056790be8e7124ad9f1988b14f5bc9d6\",\"extra2\":null,\"extra3\":null,\"payment_request_state\":\"A\",\"billing_address\":null,\"extra1\":null,\"administrative_fee\":\"0.00\",\"administrative_fee_tax\":\"0.00\",\"bank_id\":\"212\",\"nickname_buyer\":null,\"payment_method\":\"212\",\"attempts\":\"1\",\"transaction_id\":\"e5bff425-caca-4e31-9ad9-f670b93561f2\",\"transaction_date\":\"2018-11-02 12:35:19\",\"test\":\"0\",\"exchange_rate\":\"1.00\",\"ip\":\"181.230.156.157\",\"reference_pol\":\"1078709676\",\"cc_holder\":\"Bartorelli luis mario\",\"tax\":\"0.00\",\"antifraudMerchantId\":null,\"pse_bank\":null,\"state_pol\":\"4\",\"billing_city\":null,\"phone\":null,\"error_message_bank\":null,\"shipping_country\":\"AR\",\"error_code_bank\":\"0\",\"cus\":\"650068\",\"commision_pol_currency\":null,\"customer_number\":null,\"description\":\"Compra para la transaccion :82\",\"merchant_id\":\"638749\",\"administrative_fee_base\":\"0.00\",\"authorization_code\":\"650068\",\"currency\":\"ARS\",\"shipping_address\":null,\"nickname_seller\":null,\"cc_number\":\"************6201\",\"installments_number\":\"1\",\"value\":\"11000.00\",\"transaction_bank_id\":\"650068\",\"billing_country\":\"AR\",\"response_code_pol\":\"1\",\"payment_method_name\":\"MASTERCARD\",\"office_phone\":null,\"email_buyer\":\"bartorelli77@gmail.com\",\"payment_method_id\":\"2\",\"response_message_pol\":\"APPROVED\",\"airline_code\":null,\"risk\":\"0.0\",\"reference_sale\":\"82\",\"additional_value\":\"0.00\"}', 1, '2018-11-02 21:36:04', '2018-11-02 21:36:04'),
(3, '83', '{\"date\":\"2018.11.04 08:40:31\",\"pse_reference3\":null,\"payment_method_type\":\"2\",\"pse_reference2\":null,\"franchise\":\"VISA\",\"commision_pol\":\"0.00\",\"pse_reference1\":null,\"shipping_city\":null,\"bank_referenced_name\":null,\"sign\":\"17cc6dd1118496938e3c332a4a1fb795\",\"extra2\":null,\"extra3\":null,\"payment_request_state\":\"A\",\"billing_address\":null,\"extra1\":null,\"administrative_fee\":\"0.00\",\"administrative_fee_tax\":\"0.00\",\"bank_id\":\"257\",\"nickname_buyer\":null,\"payment_method\":\"257\",\"attempts\":\"1\",\"transaction_id\":\"b5f90a21-fdf0-46eb-ba96-1c00fda8982c\",\"transaction_date\":\"2018-11-04 08:40:31\",\"test\":\"0\",\"exchange_rate\":\"35.50\",\"ip\":\"179.7.192.37\",\"reference_pol\":\"1079190407\",\"cc_holder\":\"Mario Humberto Castillo Benites\",\"tax\":\"0.00\",\"antifraudMerchantId\":null,\"pse_bank\":null,\"state_pol\":\"4\",\"billing_city\":null,\"phone\":null,\"error_message_bank\":null,\"shipping_country\":\"AR\",\"error_code_bank\":\"0\",\"cus\":\"151123250\",\"commision_pol_currency\":null,\"customer_number\":null,\"description\":\"Compra para la transaccion :83\",\"merchant_id\":\"638749\",\"administrative_fee_base\":\"0.00\",\"authorization_code\":\"037130\",\"currency\":\"USD\",\"shipping_address\":null,\"nickname_seller\":null,\"cc_number\":\"************9055\",\"installments_number\":\"1\",\"value\":\"300.00\",\"transaction_bank_id\":\"037130\",\"billing_country\":\"AR\",\"response_code_pol\":\"1\",\"payment_method_name\":\"VISA\",\"office_phone\":null,\"email_buyer\":\"mariocastibeni@gmail.com\",\"payment_method_id\":\"2\",\"response_message_pol\":\"APPROVED\",\"airline_code\":null,\"risk\":\"0.02\",\"reference_sale\":\"83\",\"additional_value\":\"0.00\"}', 1, '2018-11-04 18:40:48', '2018-11-04 18:40:48'),
(4, '89', '{\"response_code_pol\":\"1\",\"phone\":null,\"additional_value\":\"0.00\",\"test\":\"0\",\"transaction_date\":\"2018-11-08 07:31:51\",\"cc_number\":\"************9684\",\"cc_holder\":\"vitale marco daniel\",\"error_code_bank\":\"0\",\"billing_country\":\"AR\",\"bank_referenced_name\":null,\"description\":\"Compra para la transaccion :89\",\"administrative_fee_tax\":\"0.00\",\"value\":\"6300.00\",\"administrative_fee\":\"0.00\",\"payment_method_type\":\"2\",\"office_phone\":null,\"email_buyer\":\"mdkvitale@yahoo.com.ar\",\"response_message_pol\":\"APPROVED\",\"error_message_bank\":null,\"shipping_city\":null,\"transaction_id\":\"32e18622-3369-457b-b952-1b1f715f6602\",\"sign\":\"9365d40ac11f7bec0b048377e9d02dcc\",\"tax\":\"0.00\",\"transaction_bank_id\":\"860104\",\"payment_method\":\"267\",\"billing_address\":null,\"payment_method_name\":\"CABAL\",\"pse_bank\":null,\"state_pol\":\"4\",\"date\":\"2018.11.08 07:31:51\",\"nickname_buyer\":null,\"reference_pol\":\"1080274804\",\"currency\":\"ARS\",\"risk\":\"0.0\",\"shipping_address\":null,\"bank_id\":\"267\",\"payment_request_state\":\"A\",\"customer_number\":null,\"administrative_fee_base\":\"0.00\",\"attempts\":\"1\",\"merchant_id\":\"638749\",\"exchange_rate\":\"1.00\",\"shipping_country\":\"AR\",\"installments_number\":\"3\",\"franchise\":\"CABAL\",\"payment_method_id\":\"2\",\"extra1\":null,\"extra2\":null,\"antifraudMerchantId\":null,\"extra3\":null,\"commision_pol_currency\":null,\"nickname_seller\":null,\"ip\":\"190.93.208.171\",\"commision_pol\":\"0.00\",\"airline_code\":null,\"billing_city\":null,\"pse_reference1\":null,\"cus\":\"151856703\",\"reference_sale\":\"89\",\"authorization_code\":\"860104\",\"pse_reference3\":null,\"pse_reference2\":null}', 1, '2018-11-08 17:31:51', '2018-11-08 17:31:51');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('1bed2d02ddf5e52da219a3d496282f4d6fb4eddfd5f365932fd0374bbba0d2e2fbd7adffd7b25ecb', 2, 2, NULL, '[\"*\"]', 1, '2018-11-13 01:36:47', '2018-11-13 01:36:47', '2018-11-27 17:36:45'),
('4536f8898bf394676c383938c105b7c365131e427865a1ed46fd5c55efa7c2254e65b750f76675ef', 4, 2, NULL, '[\"*\"]', 0, '2018-11-13 01:46:27', '2018-11-13 01:46:27', '2018-11-27 17:46:27'),
('7e0c1b2c24a8b21865526dafc24e58e6f2ca99a7b25ecddf6c03a61d7290e0b4b3dfa744fc0dff1e', 1, 2, NULL, '[\"*\"]', 0, '2018-10-26 23:03:28', '2018-10-26 23:03:28', '2018-11-10 16:03:28'),
('c535d67fd36530b97fb96eb27d7f78225fa0d8c1c3968da54798025b6228cc58bd5ce7e80d0b2119', 2, 2, NULL, '[\"*\"]', 1, '2018-10-26 21:56:09', '2018-10-26 21:56:09', '2018-11-10 14:56:09'),
('d2822dca1816c824f8d5a0d54044e7d21f7e3837c2ac4fee1c3cf6a84792ebb7fc00a93223edd4a1', 1, 2, NULL, '[\"*\"]', 0, '2018-10-29 17:00:08', '2018-10-29 17:00:08', '2018-11-13 10:00:02'),
('f26fc63a22441c42ed6fab3ff28da31d1ca095200f5b2bb9f1caadca8ef9d7e939422d2cbeeb8cf9', 2, 2, NULL, '[\"*\"]', 1, '2018-10-26 23:01:57', '2018-10-26 23:01:57', '2018-11-10 16:01:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'UwY6QSWkl9Di7baD10C7Whdt2jTVUOe7e4S7VYRB', 'http://localhost', 1, 0, 0, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(2, NULL, 'Laravel Password Grant Client', 'omAskJdWoalgHz5uxy3mRmUbf98hGAlYhArPWzDd', 'http://localhost', 0, 1, 0, '2018-10-26 21:53:22', '2018-10-26 21:53:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `oauth_refresh_tokens`
--

INSERT INTO `oauth_refresh_tokens` (`id`, `access_token_id`, `revoked`, `expires_at`) VALUES
('4bec92163b5df9473e9b7e0d7feec85d722718c21d54c655783e06044038fe59b37467d88d9be255', 'f26fc63a22441c42ed6fab3ff28da31d1ca095200f5b2bb9f1caadca8ef9d7e939422d2cbeeb8cf9', 0, '2018-11-25 16:01:57'),
('4beeb4166548bc95d07df6e1565a6d5e1dac6759773add4569176ab7db1462f85f489eccd29b02fc', 'c535d67fd36530b97fb96eb27d7f78225fa0d8c1c3968da54798025b6228cc58bd5ce7e80d0b2119', 0, '2018-11-25 14:56:09'),
('8cab3f7f78a256ea4c18c1516fb0171818bc1425602d3f3e9155e6725e9630f6a4e51c47f6521980', '1bed2d02ddf5e52da219a3d496282f4d6fb4eddfd5f365932fd0374bbba0d2e2fbd7adffd7b25ecb', 0, '2018-12-12 17:36:45'),
('a3195b8775a76602172f4a4e51f9f81bea39bea26f09903cd332ba9cffddcbefa7bd7a22abefa622', '4536f8898bf394676c383938c105b7c365131e427865a1ed46fd5c55efa7c2254e65b750f76675ef', 0, '2018-12-12 17:46:27'),
('beebc8ec6621a2a317f6a7087f165fcacbbab3b604e8726b826fc8918e494a4461192f5a99b12fa1', '7e0c1b2c24a8b21865526dafc24e58e6f2ca99a7b25ecddf6c03a61d7290e0b4b3dfa744fc0dff1e', 0, '2018-11-25 16:03:28'),
('d8faa2251c0438e71fc09ca2b61e3d45378e30f29cf012e28d80d678eea233a720d21c9062058866', 'd2822dca1816c824f8d5a0d54044e7d21f7e3837c2ac4fee1c3cf6a84792ebb7fc00a93223edd4a1', 0, '2018-11-28 10:00:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `participantes`
--

CREATE TABLE `participantes` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_postal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ciudad` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provincia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pais` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profesion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sociedad` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `encuestado` tinyint(1) DEFAULT '0',
  `categoria` enum('A','E','S') COLLATE utf8mb4_unicode_ci DEFAULT 'A',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `participantes`
--

INSERT INTO `participantes` (`id`, `nombre`, `apellido`, `codigo_postal`, `ciudad`, `provincia`, `pais`, `telefono`, `celular`, `email`, `profesion`, `sociedad`, `encuestado`, `categoria`, `created_at`, `updated_at`) VALUES
(8, 'Erica Cecilia', 'Weber', '5507', 'Lujan de Cuyo', 'Mendoza', 'Argentina', '2614983070', '154680524', 'ericacweber@yahoo.com.ar', 'Tocoginecóloga', NULL, 0, 'A', '2018-10-31 23:30:04', '2018-10-31 23:30:04'),
(9, 'sada', 'asdasñdl', 'asda', 'as', 'asdas', 'asdas', '6546541323123', '35465412312', 'asda@asdac.com', 'asdasd', NULL, 0, 'E', '2018-11-01 23:09:59', '2018-11-01 23:09:59'),
(10, 'Luis mario', 'Bartorelli', '8332', 'General roca', 'Río Negro', 'Argentina', '02984424370', '166574350', 'bartorelli77@gmail.com', 'Ginecologo', NULL, 0, 'A', '2018-11-02 21:30:39', '2018-11-02 21:30:39'),
(11, 'Mario Humberto', 'Castillo Benites', '13007', 'Trujillo', 'Trujillo', 'Perú', '+5144623598', '+51978416624', 'mariocastibeni@gmail.com', 'Medico - Ginecólogo', NULL, 0, 'E', '2018-11-04 18:38:04', '2018-11-04 18:38:04'),
(12, 'Juan', 'Brunstein', '1061', 'Pardesia', 'Hod HaSharon', 'Israel', '97298654620', '972526654620', 'jnbrunstein@gmail.com', 'Ginecologo', NULL, 0, 'E', '2018-11-05 12:17:00', '2018-11-05 12:17:00'),
(13, 'MIGUEL', 'ARELLANO', '222', 'ORURO', 'CERCADO', 'BOLIVIA', '5258355', '67002066', 'miguelangelarellanoalanez@gmail.com', 'ginecologo', NULL, 0, 'E', '2018-11-05 21:09:41', '2018-11-05 21:09:41'),
(14, 'KARINA ALEXANDRA', 'LEON PONCE', '090602', 'GUAYAQUIL', 'GUAYAS', 'ECUADOR', '59345038480', '593993302972', 'karymd77@hotmail.com', 'Especialista en Ginecologia y Obstetricia', NULL, 0, 'E', '2018-11-07 20:23:46', '2018-11-07 20:23:46'),
(15, 'Litzi Varinia', 'Lazo Vega', '00000', 'La Paz', 'Murillo', 'Bolivia', '69806008', '70684317', 'litzicita86@hotmail.com', 'Ginecóloga', NULL, 0, 'E', '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(16, 'Marco', 'Vitale', '8300', 'Neuquen', 'Neuquen', 'Argentina', '2994489966', '2994044840', 'mdkvitale@yahoo.com.ar', 'médico', 'sacil', 0, 'S', '2018-11-08 17:22:58', '2018-11-08 17:22:58'),
(17, 'Guillermina', 'Codegoni', '8407', 'Villa La Angostura', 'Neuquen', 'Argentina', '02944825485', '1159661210', 'gui.codegoni@gmail.com', 'Médica ginecóloga', NULL, 0, 'A', '2018-11-09 07:26:15', '2018-11-09 07:26:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `participante_eventos`
--

CREATE TABLE `participante_eventos` (
  `participante_id` int(10) UNSIGNED DEFAULT NULL,
  `evento_id` int(10) UNSIGNED DEFAULT NULL,
  `estado` enum('I','C','A','E') COLLATE utf8mb4_unicode_ci DEFAULT 'I',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `participante_eventos`
--

INSERT INTO `participante_eventos` (`participante_id`, `evento_id`, `estado`, `created_at`, `updated_at`) VALUES
(8, 1, 'C', '2018-10-31 23:30:05', '2018-10-31 23:32:08'),
(8, 10, 'C', '2018-10-31 23:30:05', '2018-10-31 23:32:08'),
(9, 1, 'I', '2018-11-01 23:09:59', '2018-11-01 23:09:59'),
(9, 5, 'I', '2018-11-01 23:09:59', '2018-11-01 23:09:59'),
(10, 1, 'C', '2018-11-02 21:30:39', '2018-11-02 21:36:04'),
(10, 3, 'C', '2018-11-02 21:30:39', '2018-11-02 21:36:04'),
(10, 10, 'C', '2018-11-02 21:30:39', '2018-11-02 21:36:04'),
(11, 1, 'C', '2018-11-04 18:38:06', '2018-11-04 18:40:48'),
(11, 2, 'C', '2018-11-04 18:38:06', '2018-11-04 18:40:48'),
(12, 1, 'I', '2018-11-05 12:17:01', '2018-11-05 12:17:01'),
(13, 1, 'I', '2018-11-05 21:09:42', '2018-11-05 21:09:42'),
(13, 3, 'I', '2018-11-05 21:09:42', '2018-11-05 21:09:42'),
(14, 1, 'I', '2018-11-07 20:23:47', '2018-11-07 20:23:47'),
(14, 4, 'I', '2018-11-07 20:23:47', '2018-11-07 20:23:47'),
(15, 1, 'I', '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(15, 4, 'I', '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(15, 10, 'I', '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(16, 1, 'C', '2018-11-08 17:22:58', '2018-11-08 17:31:52'),
(16, 2, 'C', '2018-11-08 17:22:58', '2018-11-08 17:31:53'),
(17, 1, 'I', '2018-11-09 07:26:15', '2018-11-09 07:26:15'),
(17, 4, 'I', '2018-11-09 07:26:15', '2018-11-09 07:26:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'usuario_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(2, 'usuario_borrar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(3, 'usuario_crear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(4, 'usuario_modificar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(5, 'usuario_autocomplete', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(6, 'usuario_search', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(7, 'permiso_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(8, 'permiso_borrar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(9, 'permiso_crear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(10, 'permiso_modificar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(11, 'permiso_autocomplete', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(12, 'permiso_search', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(13, 'rol_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(14, 'rol_borrar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(15, 'rol_crear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(16, 'rol_modificar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(17, 'rol_autocomplete', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(18, 'rol_search', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(19, 'rol_asignar_permisos', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(20, 'participante_acreditar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(21, 'participante_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(22, 'participante_autocomplete', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(23, 'participante_search', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(24, 'participante_modificar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(25, 'participante_crear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(26, 'participante_reencuestar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(27, 'participante_borrar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(28, 'encuestar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(29, 'encuesta_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(30, 'encuesta_search', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(31, 'encuesta_autocomplete', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(32, 'encuesta_crear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(33, 'encuesta_borrar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(34, 'encuesta_editar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(35, 'reporte_participantes', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(36, 'reporte_encuestas', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(37, 'evento_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(38, 'evento_search', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(39, 'evento_borrar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(40, 'evento_crear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(41, 'evento_modificar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(42, 'evento_autocomplete', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(43, 'actividad_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(44, 'actividad_search', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(45, 'actividad_borrar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(46, 'actividad_crear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(47, 'actividad_modificar', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(48, 'actividad_autocomplete', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(49, 'logs_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(50, 'faq_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(51, 'sorteo_ver', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(52, 'sortear', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'sysadmin', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(2, 'fontdesk', 'api', '2018-10-26 21:53:22', '2018-10-26 21:53:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(27, 1),
(35, 1),
(20, 2),
(21, 2),
(22, 2),
(23, 2),
(24, 2),
(25, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sorteos`
--

CREATE TABLE `sorteos` (
  `id` int(10) UNSIGNED NOT NULL,
  `encuesta_id` int(10) UNSIGNED NOT NULL,
  `posicion` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas`
--

CREATE TABLE `tarifas` (
  `id` int(10) UNSIGNED NOT NULL,
  `evento_id` int(10) UNSIGNED NOT NULL,
  `moneda` enum('ARS','USD') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ARS',
  `categoria` enum('A','E','S') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A',
  `monto` decimal(8,2) NOT NULL,
  `desde` date NOT NULL DEFAULT '1900-01-01',
  `hasta` date NOT NULL DEFAULT '3000-12-01',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tarifas`
--

INSERT INTO `tarifas` (`id`, `evento_id`, `moneda`, `categoria`, `monto`, `desde`, `hasta`, `created_at`, `updated_at`) VALUES
(1, 1, 'USD', 'E', '200.00', '1900-01-01', '2018-11-30', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(2, 1, 'USD', 'E', '230.00', '2018-12-01', '2019-02-15', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(3, 1, 'USD', 'E', '250.00', '2019-02-16', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(4, 1, 'ARS', 'A', '5000.00', '1900-01-01', '2018-11-30', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(5, 1, 'ARS', 'A', '5500.00', '2018-12-01', '2019-02-15', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(6, 1, 'ARS', 'A', '6000.00', '2019-02-16', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(7, 1, 'ARS', 'S', '4300.00', '1900-01-01', '2018-11-30', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(8, 1, 'ARS', 'S', '4600.00', '2018-12-01', '2019-02-15', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(9, 1, 'ARS', 'S', '5100.00', '2019-02-16', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(10, 2, 'ARS', 'A', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(11, 2, 'USD', 'E', '100.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(12, 2, 'ARS', 'S', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(13, 3, 'ARS', 'A', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(14, 3, 'USD', 'E', '100.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(15, 3, 'ARS', 'S', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(16, 4, 'ARS', 'A', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(17, 4, 'USD', 'E', '100.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(18, 4, 'ARS', 'S', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(19, 5, 'ARS', 'A', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(20, 5, 'USD', 'E', '100.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(21, 5, 'ARS', 'S', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(22, 6, 'ARS', 'A', '10000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(23, 6, 'USD', 'E', '250.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(24, 6, 'ARS', 'S', '10000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(25, 7, 'ARS', 'A', '6000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(26, 7, 'USD', 'E', '150.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(27, 7, 'ARS', 'S', '6000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(28, 8, 'ARS', 'A', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(29, 8, 'USD', 'E', '100.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(30, 8, 'ARS', 'S', '2000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(31, 9, 'ARS', 'A', '1200.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(32, 9, 'USD', 'E', '30.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(33, 9, 'ARS', 'S', '1200.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(34, 10, 'ARS', 'A', '4000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(35, 10, 'USD', 'E', '100.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(36, 10, 'ARS', 'S', '4000.00', '1900-01-01', '3000-12-01', '2018-10-26 21:53:22', '2018-10-26 21:53:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transacciones`
--

CREATE TABLE `transacciones` (
  `id` int(10) UNSIGNED NOT NULL,
  `estado` enum('4','6','104','5','7') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '7',
  `participante_id` int(10) UNSIGNED NOT NULL,
  `moneda` enum('ARS','USD') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ARS',
  `monto` decimal(8,2) NOT NULL,
  `codigo_payu` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `transacciones`
--

INSERT INTO `transacciones` (`id`, `estado`, `participante_id`, `moneda`, `monto`, `codigo_payu`, `created_at`, `updated_at`) VALUES
(80, '4', 8, 'ARS', '9000.00', '1078047178', '2018-10-31 23:30:05', '2018-10-31 23:32:08'),
(81, '7', 9, 'USD', '300.00', NULL, '2018-11-01 23:10:00', '2018-11-01 23:10:00'),
(82, '4', 10, 'ARS', '11000.00', '1078709676', '2018-11-02 21:30:39', '2018-11-02 21:36:04'),
(83, '4', 11, 'USD', '300.00', '1079190407', '2018-11-04 18:38:06', '2018-11-04 18:40:48'),
(84, '7', 12, 'USD', '200.00', NULL, '2018-11-05 12:17:01', '2018-11-05 12:17:01'),
(85, '7', 13, 'USD', '300.00', NULL, '2018-11-05 21:09:42', '2018-11-05 21:09:42'),
(86, '7', 14, 'USD', '300.00', NULL, '2018-11-07 20:23:47', '2018-11-07 20:23:47'),
(87, '7', 15, 'USD', '400.00', NULL, '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(88, '7', 15, 'USD', '400.00', NULL, '2018-11-07 21:12:18', '2018-11-07 21:12:18'),
(89, '4', 16, 'ARS', '6300.00', '1080274804', '2018-11-08 17:22:58', '2018-11-08 17:31:51'),
(90, '7', 17, 'ARS', '7000.00', NULL, '2018-11-09 07:26:15', '2018-11-09 07:26:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transacciones_tarifas`
--

CREATE TABLE `transacciones_tarifas` (
  `transaccion_id` int(10) UNSIGNED DEFAULT NULL,
  `tarifa_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `transacciones_tarifas`
--

INSERT INTO `transacciones_tarifas` (`transaccion_id`, `tarifa_id`, `created_at`, `updated_at`) VALUES
(80, 4, '2018-10-31 23:30:05', '2018-10-31 23:30:05'),
(80, 34, '2018-10-31 23:30:05', '2018-10-31 23:30:05'),
(81, 1, '2018-11-01 23:10:00', '2018-11-01 23:10:00'),
(81, 20, '2018-11-01 23:10:00', '2018-11-01 23:10:00'),
(82, 4, '2018-11-02 21:30:39', '2018-11-02 21:30:39'),
(82, 13, '2018-11-02 21:30:39', '2018-11-02 21:30:39'),
(82, 34, '2018-11-02 21:30:39', '2018-11-02 21:30:39'),
(83, 1, '2018-11-04 18:38:06', '2018-11-04 18:38:06'),
(83, 11, '2018-11-04 18:38:06', '2018-11-04 18:38:06'),
(84, 1, '2018-11-05 12:17:01', '2018-11-05 12:17:01'),
(85, 1, '2018-11-05 21:09:42', '2018-11-05 21:09:42'),
(85, 14, '2018-11-05 21:09:42', '2018-11-05 21:09:42'),
(86, 1, '2018-11-07 20:23:47', '2018-11-07 20:23:47'),
(86, 17, '2018-11-07 20:23:47', '2018-11-07 20:23:47'),
(87, 1, '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(87, 17, '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(87, 35, '2018-11-07 21:10:36', '2018-11-07 21:10:36'),
(88, 1, '2018-11-07 21:12:18', '2018-11-07 21:12:18'),
(88, 17, '2018-11-07 21:12:18', '2018-11-07 21:12:18'),
(88, 35, '2018-11-07 21:12:18', '2018-11-07 21:12:18'),
(89, 7, '2018-11-08 17:22:58', '2018-11-08 17:22:58'),
(89, 12, '2018-11-08 17:22:58', '2018-11-08 17:22:58'),
(90, 4, '2018-11-09 07:26:15', '2018-11-09 07:26:15'),
(90, 16, '2018-11-09 07:26:15', '2018-11-09 07:26:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `evento_id` int(10) UNSIGNED NOT NULL,
  `grupo` enum('admin','congreso') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'congreso',
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `nombre`, `email`, `password`, `evento_id`, `grupo`, `estado`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin1@div-it.com.ar', '$2y$10$97bhVB6USE86cB1zbaFFO.6LekOgtta4xzuAnEaMSnrlZkocLuRiu', 1, 'admin', 1, NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(2, 'Sysadmin', 'webmaster1@div-it.com.ar', '$2y$10$l04g72aREuHAwTWaxVuhJO6UJJIqqv2onDqthizMBPuv7S.l29AOa', 1, 'congreso', 1, NULL, '2018-10-26 21:53:22', '2018-10-26 21:53:22'),
(3, 'Administrator', 'admin2@div-it.com.ar', '$2y$10$O5JJYWup/6l.juV22ZNVDu9N1OllZHRTvpGPReiXGLxg3UMJseWSu', 2, 'admin', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(4, 'Sysadmin', 'webmaster2@div-it.com.ar', '$2y$10$xo7NxPGaavUbCAGQafL0Aeu0rEjnte6Q6e7Ird3hlt5O78lT8F/l.', 2, 'congreso', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(5, 'Administrator', 'admin3@div-it.com.ar', '$2y$10$UPN0M1JFm7Ej6IxjJh.6WeEQJS00thihlKu57vOAwg6qrW962qmmO', 3, 'admin', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(6, 'Sysadmin', 'webmaster3@div-it.com.ar', '$2y$10$JVfS6vQ/SdMO10A4eH4Ar.CZVL/c5nsfOPuOwOSkS0OwCr4NChiku', 3, 'congreso', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(7, 'Administrator', 'admin4@div-it.com.ar', '$2y$10$t7E6vZPSyKNn6u2cxuEDzeCWroh1YRnRD0oCmeFPJ9WF98vHeYKTi', 4, 'admin', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(8, 'Sysadmin', 'webmaster4@div-it.com.ar', '$2y$10$ARaiDIzCPQpWjUib.H5UOOgdhw7nDzOnjyjPnIm9yE3NY1idvdS4e', 4, 'congreso', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(9, 'Administrator', 'admin5@div-it.com.ar', '$2y$10$5vfxUFx5g2v9gHZbvlFUQeVfQjXkqolKOAMDIwhuY.3HlSCi/G3di', 5, 'admin', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(10, 'Sysadmin', 'webmaster5@div-it.com.ar', '$2y$10$1oI3lIQNApd6TracytM0cO2Dxhnk7jpY2SYLqrHwYk1.5DnPf/T7y', 5, 'congreso', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(11, 'Administrator', 'admin6@div-it.com.ar', '$2y$10$qM9GjcduU8Kzii7CI0wmteFPVQgd0YzKKGShBfpyAuotfKeBTp9vi', 6, 'admin', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(12, 'Sysadmin', 'webmaster6@div-it.com.ar', '$2y$10$PfXbsu3.Zuiq/Vv5.vc6beDJJ6VHsWiLUtjXPl5mpylItEe6sLJKe', 6, 'congreso', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(13, 'Administrator', 'admin7@div-it.com.ar', '$2y$10$zpQ/Xo.oXd3qhI6C5J71f.N4n501FN.djJTjn6QnoqRkUI0i5WaZO', 7, 'admin', 1, NULL, '2018-10-26 21:53:23', '2018-10-26 21:53:23'),
(14, 'Sysadmin', 'webmaster7@div-it.com.ar', '$2y$10$K4Ebaku5kAKW8XYRRrT2WezGGCi.U/mVAlqWTO/LITgwxYd/.8WPm', 7, 'congreso', 1, NULL, '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(15, 'Administrator', 'admin8@div-it.com.ar', '$2y$10$FcnQra7HZTz3kz0H74MkCOXm8AnWbDXZvTlIPedWZS2moIB61.Z6e', 8, 'admin', 1, NULL, '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(16, 'Sysadmin', 'webmaster8@div-it.com.ar', '$2y$10$oUq7ZNJqpa4beD85TBOdwuDsU8xzHITJyfTRFc3OZqqIUk6EDUQO2', 8, 'congreso', 1, NULL, '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(17, 'Administrator', 'admin9@div-it.com.ar', '$2y$10$2EPl46Ycjw60zIRSxsk1ouae3Z7gRc1rbP/SakzmgwvMVNJZ7m0jq', 9, 'admin', 1, NULL, '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(18, 'Sysadmin', 'webmaster9@div-it.com.ar', '$2y$10$nu3u18/1OJ2i04SYHN.yi.N4yQKW89sDNxWozXsdyDm2DNOrmhpGS', 9, 'congreso', 1, NULL, '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(19, 'Administrator', 'admin10@div-it.com.ar', '$2y$10$PHM5hDZBA.Z9RSb4BdAcFeCOsIA3A0ZNOviO30gkyT6Yw8Rs0LvlO', 10, 'admin', 1, NULL, '2018-10-26 21:53:24', '2018-10-26 21:53:24'),
(20, 'Sysadmin', 'webmaster10@div-it.com.ar', '$2y$10$z4lWwCsB8xXwusxHxN9JV.A5kqAK/.C0RzhMJbUBLTe0SFKYuxlvG', 10, 'congreso', 1, NULL, '2018-10-26 21:53:24', '2018-10-26 21:53:24');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `actividades`
--
ALTER TABLE `actividades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `actividades_evento_id_foreign` (`evento_id`);

--
-- Indices de la tabla `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `encuestas_participante_id_unique` (`participante_id`),
  ADD UNIQUE KEY `encuestas_email_unique` (`email`);

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `eventos_path_unique` (`path`),
  ADD UNIQUE KEY `eventos_nombre_unique` (`nombre`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indices de la tabla `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indices de la tabla `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indices de la tabla `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indices de la tabla `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indices de la tabla `participantes`
--
ALTER TABLE `participantes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `participantes_email_unique` (`email`);

--
-- Indices de la tabla `participante_eventos`
--
ALTER TABLE `participante_eventos`
  ADD UNIQUE KEY `participante_eventos_participante_id_evento_id_unique` (`participante_id`,`evento_id`),
  ADD KEY `participante_eventos_evento_id_foreign` (`evento_id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indices de la tabla `sorteos`
--
ALTER TABLE `sorteos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sorteos_encuesta_id_foreign` (`encuesta_id`);

--
-- Indices de la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tarifas_evento_id_categoria_desde_hasta_unique` (`evento_id`,`categoria`,`desde`,`hasta`);

--
-- Indices de la tabla `transacciones`
--
ALTER TABLE `transacciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transacciones_participante_id_foreign` (`participante_id`);

--
-- Indices de la tabla `transacciones_tarifas`
--
ALTER TABLE `transacciones_tarifas`
  ADD KEY `transacciones_tarifas_transaccion_id_foreign` (`transaccion_id`),
  ADD KEY `transacciones_tarifas_tarifa_id_foreign` (`tarifa_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_evento_id_foreign` (`evento_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `actividades`
--
ALTER TABLE `actividades`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `participantes`
--
ALTER TABLE `participantes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `sorteos`
--
ALTER TABLE `sorteos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tarifas`
--
ALTER TABLE `tarifas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de la tabla `transacciones`
--
ALTER TABLE `transacciones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `actividades`
--
ALTER TABLE `actividades`
  ADD CONSTRAINT `actividades_evento_id_foreign` FOREIGN KEY (`evento_id`) REFERENCES `eventos` (`id`);

--
-- Filtros para la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD CONSTRAINT `encuestas_participante_id_foreign` FOREIGN KEY (`participante_id`) REFERENCES `participantes` (`id`);

--
-- Filtros para la tabla `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `participante_eventos`
--
ALTER TABLE `participante_eventos`
  ADD CONSTRAINT `participante_eventos_evento_id_foreign` FOREIGN KEY (`evento_id`) REFERENCES `eventos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `participante_eventos_participante_id_foreign` FOREIGN KEY (`participante_id`) REFERENCES `participantes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `sorteos`
--
ALTER TABLE `sorteos`
  ADD CONSTRAINT `sorteos_encuesta_id_foreign` FOREIGN KEY (`encuesta_id`) REFERENCES `encuestas` (`id`);

--
-- Filtros para la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD CONSTRAINT `tarifas_evento_id_foreign` FOREIGN KEY (`evento_id`) REFERENCES `eventos` (`id`);

--
-- Filtros para la tabla `transacciones`
--
ALTER TABLE `transacciones`
  ADD CONSTRAINT `transacciones_participante_id_foreign` FOREIGN KEY (`participante_id`) REFERENCES `participantes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `transacciones_tarifas`
--
ALTER TABLE `transacciones_tarifas`
  ADD CONSTRAINT `transacciones_tarifas_tarifa_id_foreign` FOREIGN KEY (`tarifa_id`) REFERENCES `tarifas` (`id`),
  ADD CONSTRAINT `transacciones_tarifas_transaccion_id_foreign` FOREIGN KEY (`transaccion_id`) REFERENCES `transacciones` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_evento_id_foreign` FOREIGN KEY (`evento_id`) REFERENCES `eventos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
